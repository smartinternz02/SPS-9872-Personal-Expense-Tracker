# Budgets on Fire

Budgets on Fire is a web-based expense tracker

## Features

Aside from the static pages discussing finances, the website allows users to register/login to view protected pages, enter in expenses, keep a running total of their account balance, and organize expenses by category.

## Resources used

Front-end: Bootstrap template
Back-end: Python
Database: SQLite3
